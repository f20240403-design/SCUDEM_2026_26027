## Import modules
from abaqus import *
from abaqusConstants import *
from caeModules import *
import numpy as np
import os

jobName='./Job-dynamic'

# Open File Odb   
myViewport = session.Viewport(name='Viewport-Results')
myViewport.makeCurrent(); myViewport.maximize()
myOdb = visualization.openOdb(path=jobName + '.odb')
myViewport.setValues(displayedObject=myOdb)
a = myOdb.rootAssembly

# Loop on all frames
sensors_names = ['MEDDIST', 'LATDIST' ,'ANTDIST', 'POSTPROX', 'ANTPROX', 'MEDPROX' ,'LATPROX'];
allFrames = myOdb.steps['Dynamic'].frames

fileObj = open('./PresMeasSimu.txt',"w")

for f in range(1, len(allFrames)):
    
    frame = allFrames[f]
    # Create result file
    perc = frame.frameValue
    
    mean_pressures = np.zeros((7,1))
    for sensor in range(7):
        
        vals_sensor = []
        region = a.nodeSets['SENSORNODES-'+sensors_names[sensor]]
        vals = frame.fieldOutputs['CPRESS'].getSubset(region=region).values
        
        for nd in range(len(vals)):
            sensorPressure = vals[nd].data
            vals_sensor.append(sensorPressure)
        
        mean_pressures[sensor] = np.mean(vals_sensor)*1000
    
    fileObj.write("%.3f "  %(perc))
    fileObj.write("%.2f %.2f %.2f %.2f %.2f %.2f %.2f \n"  %(mean_pressures[0],mean_pressures[1],mean_pressures[2],mean_pressures[3],mean_pressures[4],mean_pressures[5],mean_pressures[6]))

fileObj.close()
# Close odb File
session.odbs[jobName + '.odb'].close()