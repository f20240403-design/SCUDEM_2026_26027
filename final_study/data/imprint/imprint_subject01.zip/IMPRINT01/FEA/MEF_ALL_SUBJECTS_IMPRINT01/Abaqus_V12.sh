#!/bin/bash

## This script is to be used ONLY FOR ABAQUS COMPUTATIONS

### User fill in HERE
#
## Required batch arguments
#SBATCH --job-name=JOBNAME
#SBATCH --partition=CPU_Compute
#SBATCH --ntasks=12
#SBATCH --nodes=1
#
## Optional batch arguments (uncomment if used)
## SBATCH --time=00:30:00
#
#SBATCH --mail-type=ALL
##SBATCH --mail-user=user@mail.fqdn
#
## Suggested batch arguments 
#SBATCH --output=slurm_%j.out
#SBATCH --error=slurm_%j.err


### Input & user files can be specified here
INPUT=Job-dynamic              # INPUT must be *.inp file
DISP=                       # Write your subroutine name (umat, vumat, disp...)
#
PRE_PROCESSING_SCRIPT=        # Python script
POST_PROCESSING_SCRIPT=POST_PROCESSING.py

### Module selection
MODULE=ABAQUS/2021         # Write here module (send module avail for a list)
COMMAND=abaqus            # Abaqus command (abq6145,abq2019, ...)


### License Server Location
## Please, use IP instead of hostname whenever possible
LICENSE_SERVER=27011@AM-SRVLIC-2.intram.ensam.eu



#####################################
#                                   #
###  DO NOT EDIT BELOW THIS LINE  ###
# UNLESS YOU KNOW WHAT YOU'RE DOING #
#                                   #
#####################################

# Print help if no arguments at all are given:
if [  "$1" == "-h" ] || [ "$1" == "--help" ]; then 
    echo -e "\033[034mScript usage:\033[0m"
    echo -e ""
    echo -e "Please, only use this script for ABAQUS computations"
    echo -e ""
    echo -e "\033[34mArguments:\033[0m"
    echo -e "\t$1 -> input file (.inp)"
    echo -e "\t$2 (optional) -> user file (.o, .f, ...)"
    echo -e ""
    echo -e "\033[34mExample:\033[0m"
    echo -e "\t$ sbatch ABAQUS.sh input.inp user.f"
    echo -e ""
    echo -e "\033[34mAny question ? Please, contact us at cassiopee@ensam.eu\033[0m"
fi

#
### Or input & user file can be passed as argument:
## $1=inp $2=user
# e.g. $sbatch ABAQUS.sh FILE.inp USER.*
#
if [ -z $INPUT ]; then
    INPUT=$1
fi
#
if [ -z $DISP ]; then
    DISP=$2
fi
#

### --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- ###

### --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- ###
### Writing variables
echo ""
echo -e "\033[34m---------------------------------------------------------------------------------------\033[0m"
echo -e "\033[34mVariables Summary: \033[0m"
echo -e "\tWorking Directory = $SLURM_SUBMIT_DIR"
echo -e "\tJob ID = $SLURM_JOB_ID"
echo -e "\tJob Name = $SLURM_JOB_NAME"
echo -e "\tJob inp = $INPUT"
echo -e "\tJob Hosts = $SLURM_JOB_NODELIST"
echo -e "\tNumber of Nodes = $SLURM_NNODES"
echo -e "\tNumber of Cores = $SLURM_NTASKS"
echo -e "\tCores per Node = $SLURM_NTASKS_PER_NODE"

### --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- ###
### Module Selection
echo ""
echo -e "\033[34m--------------------------------------------------------------------------------------\033[0m"
echo -e "\033[34mSelecting modules...\033[0m"
unset SLURM_GTIDS   # This directive is mandatory for use with Abaqus
module purge
module load EasyBuild "$MODULE"
#Choose your compiler: intel of foss
module load intel
echo -e "\tModule $MODULE loaded"
#
### License Export
export LM_LICENSE_FILE=$LICENSE_SERVER
export ABAQUSLM_LICENSE_FILE=$LICENSE_SERVER
### --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- ###
#
#
node_list=( $(srun hostname | sort -r | uniq -c) ) 
mp_host_list="["
for (( index=0; index<${#node_list[@]}; index+=2 )); do
    mp_host_list="${mp_host_list}['${node_list[index+1]}',${node_list[index]}],"
done
mp_host_list="${mp_host_list::-1}]"
echo "mp_host_list=${mp_host_list}" > "slurm-${SLURM_JOB_ID}_abaqus_v6.env"
if ! grep -Fxq "import os" abaqus_v6.env
then
    echo "import os" >> abaqus_v6.env
fi
if ! grep -Fxq "if 'SLURM_JOB_ID' in os.environ: execfile('slurm-'+os.getenv('SLURM_JOB_ID', default=None)+'_abaqus_v6.env')" abaqus_v6.env
then
    echo "if 'SLURM_JOB_ID' in os.environ: execfile('slurm-'+os.getenv('SLURM_JOB_ID', default=None)+'_abaqus_v6.env')" >> abaqus_v6.env
fi
#
#
### --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- ###
### PRE-PROCESSING
if [ ! -z "$PRE_PROCESSING_SCRIPT" ]; then
    echo -e "\n\033[34mEntering Pre-Processing\033[0m"
    #
    "$COMMAND" cae noGUI="$PRE_PROCESSING_SCRIPT" 
    #
    echo -e "\n\033[34mExiting Pre-Processing\033[0m"
fi

### Send command
echo -e "\n\033[34mStarting Abaqus Computation...\033[0m"
    if [ -z $DISP ]; then
	"$COMMAND" job="$INPUT" cpus="$SLURM_NTASKS" int
    else
	"$COMMAND" job="$INPUT" user="$DISP" cpus="$SLURM_NTASKS" int
    fi

### POST-PROCESSING
if [ ! -z "$POST_PROCESSING_SCRIPT" ]; then
    echo -e "\n\033[34mEntering Post-Processing\033[0m"
    #
    "$COMMAND" cae noGUI="$POST_PROCESSING_SCRIPT" 
    #
echo -e "\n\033[34mExiting Post-Processing\033[0m"
fi
### --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- ###


### EOF

sleep 5
touch fincalcul.dat
