from abaqusConstants import *
import __main__
import section
import regionToolset
import displayGroupMdbToolset as dgm
import part
import material
import assembly
import step
import interaction
import load
import mesh
import optimization
import job
import sketch
import visualization
import xyPlot
import displayGroupOdbToolset as dgo
import numpy as np
import sys 
 
session.journalOptions.replayGeometry
session.journalOptions.setValues(replayGeometry=INDEX) 

# --------- DEFINE PARAMETERS ---------                      
subject_weight = 80.5
mesh_size = 5
nu = 0.49
Est = 0.250
Epat = 0.250
Esi = 0.600
friction = 0.5

# ---------- LOAD SOCKET ------------
# Socket
acis = mdb.openAcis('./parts/inside_EOS.sat', scaleFromFile=OFF)
mdb.models['Model-1'].PartFromGeometryFile(name='socket', 
    geometryFile=acis, combine=False, dimensionality=THREE_D, 
    type=DEFORMABLE_BODY)

# Residual limb 
acis = mdb.openAcis('./parts/inner_stump.sat', scaleFromFile=OFF)
mdb.models['Model-1'].PartFromGeometryFile(name='full_residual', 
    geometryFile=acis, combine=False, dimensionality=THREE_D, 
    type=DEFORMABLE_BODY)

# Patellar tendon
acis = mdb.openAcis('./parts/patellar_tendon.sat', scaleFromFile=OFF)
mdb.models['Model-1'].PartFromGeometryFile(name='patellar_tendon', 
    geometryFile=acis, combine=False, dimensionality=THREE_D, 
    type=DEFORMABLE_BODY)

# liner 
acis = mdb.openAcis('./parts/liner.sat', scaleFromFile=OFF)
mdb.models['Model-1'].PartFromGeometryFile(name='liner', 
    geometryFile=acis, combine=False, dimensionality=THREE_D, 
    type=DEFORMABLE_BODY)
    
# Bones
acis = mdb.openAcis('./parts/femur.sat', scaleFromFile=OFF)
mdb.models['Model-1'].PartFromGeometryFile(name='cond_femur', 
    geometryFile=acis, combine=False, dimensionality=THREE_D, 
    type=DEFORMABLE_BODY)

acis = mdb.openAcis('./parts/tibia.sat', scaleFromFile=OFF)
mdb.models['Model-1'].PartFromGeometryFile(name='tibia', 
    geometryFile=acis, combine=False, dimensionality=THREE_D, 
    type=DEFORMABLE_BODY)

acis = mdb.openAcis('./parts/rotule.sat', scaleFromFile=OFF)
mdb.models['Model-1'].PartFromGeometryFile(name='patella', 
    geometryFile=acis, combine=False, dimensionality=THREE_D, 
    type=DEFORMABLE_BODY)

# ---------- OPEN .INP MESHES -----------

mdb.models['Model-1'].PartFromInputFile(inputFileName='./parts/mean_femurd_inputMesh.inp')
mdb.models['Model-1'].PartFromInputFile(inputFileName='./parts/mean_tibiad_inputMesh.inp')
mdb.models['Model-1'].PartFromInputFile(inputFileName='./parts/rotuled_inputMesh.inp')

# ----------- CREATE ASSEMBLY --------------

# .sat files
p_socket = mdb.models['Model-1'].parts['socket']
p_tibia_sat = mdb.models['Model-1'].parts['tibia']
p_patella_sat = mdb.models['Model-1'].parts['patella']
p_condyles_sat = mdb.models['Model-1'].parts['cond_femur']
p_residual = mdb.models['Model-1'].parts['full_residual']
p_liner = mdb.models['Model-1'].parts['liner']
p_pt = mdb.models['Model-1'].parts['patellar_tendon']

# Partition liner
e = p_liner.edges
edges = e[1:5]+e[6:12]+e[13:51]+e[55:92]
verts = p_liner.vertices[0:59]
pickedEntities =(verts, edges, )
p_liner.ignoreEntity(entities=pickedEntities)

aPlane = p_liner.DatumPlaneByPrincipalPlane(principalPlane=XYPLANE, offset=650.0).id
bPlane = p_liner.DatumPlaneByPrincipalPlane(principalPlane=YZPLANE, offset=0.0).id
cPlane = p_liner.DatumPlaneByPrincipalPlane(principalPlane=XZPLANE, offset=-125.0).id
dPlane = p_liner.DatumPlaneByPrincipalPlane(principalPlane=XYPLANE, offset=840.0).id

p_liner.PartitionCellByDatumPlane(datumPlane=p_liner.datums[bPlane], cells=p_liner.cells)
p_liner.PartitionCellByDatumPlane(datumPlane=p_liner.datums[cPlane], cells=p_liner.cells)
p_liner.PartitionCellByDatumPlane(datumPlane=p_liner.datums[aPlane], cells=p_liner.cells)
p_liner.PartitionCellByDatumPlane(datumPlane=p_liner.datums[dPlane], cells=p_liner.cells)

# .inp meshes
p_tibia = mdb.models['Model-1'].parts['MEAN_TIBIAD']
p_patella = mdb.models['Model-1'].parts['ROTULED']
p_condyles = mdb.models['Model-1'].parts['MEAN_FEMURD']

#Create Instances
a = mdb.models['Model-1'].rootAssembly
a.DatumCsysByDefault(CARTESIAN)

#.sat parts
a.Instance(name='socket', part=p_socket, dependent=ON)
a.Instance(name='full_residual', part=p_residual, dependent=ON)
a.Instance(name='patellar_tendon', part=p_pt, dependent=ON)
a.Instance(name='tibia_sat', part=p_tibia_sat, dependent=ON)
a.Instance(name='condyles_sat', part=p_condyles_sat, dependent=ON)
a.Instance(name='patella_sat', part=p_patella_sat, dependent=ON)
a.Instance(name='liner', part=p_liner, dependent=ON)
#.inp meshes
a.Instance(name='tibia', part=p_tibia, dependent=ON)
a.Instance(name='condyles', part=p_condyles, dependent=ON)
a.Instance(name='patella', part=p_patella, dependent=ON)


# read knee and ankle centers
jointsFile = './data/initial_joint_centers.txt'
loadFile = open(jointsFile, 'r')
lines = loadFile.readlines()
knee_str = re.findall(r"[-+]?\d*\.?\d+|[-+]?\d+", lines[0])
ankle_str = re.findall(r"[-+]?\d*\.?\d+|[-+]?\d+", lines[1])
knee = list(map(float,knee_str))
ankle = list(map(float,ankle_str))

# Compute socket ref frame
myFile = './data/socket_frame.txt'
frameFile = open(myFile, 'r')
lines = frameFile.readlines()
vec = (4, 4)
vec = np.zeros(vec)
for l in range(len(lines)):
    line = re.findall(r"[-+]?\d*\.?\d+|[-+]?\d+", lines[l])
    for m in range(len(line)):
        vec[m][l] = line[m]

x_dir=vec[0][0:3]
y_dir=vec[1][0:3]
# Create the Datum CSYS
datumCsysId = a.DatumCsysByThreePoints(name='Socket_Csys',
    coordSysType=CARTESIAN, origin=knee,
    point1=(knee[0] + x_dir[0], knee[1] + x_dir[1], knee[2] + x_dir[2]),
    point2=(knee[0] + y_dir[0], knee[1] + y_dir[1], knee[2] + y_dir[2])).id
datum = a.datums[datumCsysId]

# boolean cut 
a.InstanceFromBooleanCut(name='residual', 
    instanceToBeCut=a.instances['full_residual'], 
    cuttingInstances=(a.instances['tibia_sat'],
    a.instances['condyles_sat'], 
    a.instances['patella_sat'], ), 
    originalInstances=SUPPRESS)
del a.features['full_residual']
p_residual = mdb.models['Model-1'].parts['residual']

a.resumeFeatures(('tibia_sat', 'condyles_sat', 'patella_sat', ))
a.InstanceFromBooleanCut(name='tendon', 
    instanceToBeCut=a.instances['patellar_tendon'], 
    cuttingInstances=(a.instances['tibia_sat'],
    a.instances['condyles_sat'], a.instances['patella_sat'],), 
    originalInstances=SUPPRESS)
del a.features['patellar_tendon']
p_pt = mdb.models['Model-1'].parts['tendon']

# ---------- CREATE AND ASSIGN MATERIAL PROPERTIES -------------

#Create Material porperties
#PA12
mdb.models['Model-1'].Material(name='PA12')
mdb.models['Model-1'].materials['PA12'].Elastic(table=((1600, 0.3), ))
#Soft Tissues
C10 = Est/(4*(1+nu))
D1 = (6*(1-2*nu))/Est
mdb.models['Model-1'].Material(name='SoftTissues')
mdb.models['Model-1'].materials['SoftTissues'].Hyperelastic(
    materialType=ISOTROPIC, testData=OFF, type=NEO_HOOKE, 
    volumetricResponse=VOLUMETRIC_DATA, table=((C10, D1), ))
#Patella
C10 = Epat/(4*(1+nu))
D1 = (6*(1-2*nu))/Epat
mdb.models['Model-1'].Material(name='PatellarTendon')
mdb.models['Model-1'].materials['PatellarTendon'].Hyperelastic(
    materialType=ISOTROPIC, testData=OFF, type=NEO_HOOKE, 
    volumetricResponse=VOLUMETRIC_DATA, table=((C10, D1), ))                                
#Silicone
C10 = Esi/(4*(1+nu))
D1 = (6*(1-2*nu))/Esi
mdb.models['Model-1'].Material(name='Silicon')
mdb.models['Model-1'].materials['Silicon'].Hyperelastic(
    materialType=ISOTROPIC, testData=OFF, type=NEO_HOOKE, 
    volumetricResponse=VOLUMETRIC_DATA, table=((C10, D1), ))
#Bones
mdb.models['Model-1'].Material(name='Bone')
mdb.models['Model-1'].materials['Bone'].Elastic(table=((10000, 0.3), ))

#Create sections
# read thickness data and create a mapped field
with open('./data/real_shell_thickness.txt', 'r') as file:
    lines = file.readlines()

nodal_thickness = []
labels = []
for line in lines:
    # Split the line by commas and convert to float
    data = tuple(map(float, line.strip().split(',')))
    labels.append(int(data[0]))
    nodal_thickness.append(data[1])

mdb.models['Model-1'].DiscreteField(name='DiscField-1', description='', 
    location=NODES, fieldType=SCALAR, dataWidth=1, defaultValues=(10.0, ), 
    data=(('', 1, tuple(labels), tuple(nodal_thickness)), ))
mdb.models['Model-1'].HomogeneousShellSection(name='socket', 
    preIntegrate=OFF, material='PA12', thickness=0.0, thicknessType=NODAL_DISCRETE_FIELD, 
    nodalThicknessField='DiscField-1', idealization=NO_IDEALIZATION, 
    poissonDefinition=DEFAULT, thicknessModulus=None, temperature=GRADIENT, useDensity=OFF, 
    integrationRule=SIMPSON, numIntPts=5)
    
mdb.models['Model-1'].HomogeneousSolidSection(name='residual', 
    material='SoftTissues', thickness=None)
mdb.models['Model-1'].HomogeneousSolidSection(name='tendon', 
    material='PatellarTendon', thickness=None)
mdb.models['Model-1'].HomogeneousSolidSection(name='liner', 
    material='Silicon', thickness=None)
    
mdb.models['Model-1'].HomogeneousShellSection(name='bones', 
    preIntegrate=OFF, material='Bone', thicknessType=UNIFORM, 
    thickness=0.1, thicknessField='', nodalThicknessField='', 
    idealization=NO_IDEALIZATION, poissonDefinition=DEFAULT, 
    thicknessModulus=None, temperature=GRADIENT, useDensity=OFF, 
    integrationRule=SIMPSON, numIntPts=5)
    
#Assign sections
region = p_socket.Set(faces=p_socket.faces, name='Set-socket')
p_socket.SectionAssignment(region=region, sectionName='socket', offset=0.0, 
    offsetType=TOP_SURFACE, offsetField='', 
    thicknessAssignment=FROM_SECTION)

region = p_tibia.Set(elements=p_tibia.elements, name='Set-tibia')
p_tibia.SectionAssignment(region=region, sectionName='bones', offset=0.0, 
    offsetType=MIDDLE_SURFACE, offsetField='', 
    thicknessAssignment=FROM_SECTION)
    
region = p_patella.Set(elements=p_patella.elements, name='Set-patella')
p_patella.SectionAssignment(region=region, sectionName='bones', offset=0.0, 
    offsetType=MIDDLE_SURFACE, offsetField='', 
    thicknessAssignment=FROM_SECTION)
    
region = p_condyles.Set(elements=p_condyles.elements, name='Set-condyles')
p_condyles.SectionAssignment(region=region, sectionName='bones', offset=0.0, 
    offsetType=MIDDLE_SURFACE, offsetField='', 
    thicknessAssignment=FROM_SECTION)
    
region = p_residual.Set(cells=p_residual.cells, name='Set-residual')
p_residual.SectionAssignment(region=region, sectionName='residual', offset=0.0, 
    offsetType=MIDDLE_SURFACE, offsetField='', 
    thicknessAssignment=FROM_SECTION)
    
region = p_pt.Set(cells=p_pt.cells, name='Set-tendon')
p_pt.SectionAssignment(region=region, sectionName='tendon', offset=0.0, 
    offsetType=MIDDLE_SURFACE, offsetField='', 
    thicknessAssignment=FROM_SECTION)
region = p_liner.Set(cells=p_liner.cells, name='Set-liner')
p_liner.SectionAssignment(region=region, sectionName='liner', offset=0.0, 
    offsetType=MIDDLE_SURFACE, offsetField='', 
    thicknessAssignment=FROM_SECTION)


# define faces
f_socket = a.instances['socket'].faces
f_residual = a.instances['residual-1'].faces
f_tendon = a.instances['tendon-1'].faces
f_liner = a.instances['liner'].faces
f_pt =  a.instances['tendon-1'].faces

f_link_residual = f_residual[83:84]
f_link_tendon = f_tendon[63:64]

f_int_residual = f_residual[0:83]
f_int_residual_labels = [face.index for face in f_int_residual+f_link_residual]

f_int_tendon = f_tendon[0:43]+f_tendon[44:63]
f_int_tendon_labels = [face.index for face in f_int_tendon+f_link_tendon]


# f_ext_residual
remaining_faces = []
for face in f_residual:
    if not (face.index in f_int_residual_labels or face.index == f_link_residual.index):
        remaining_faces.append(face.index)

f_ext_residual = f_residual[remaining_faces[0]:remaining_faces[0]+1]
for i in range(1,len(remaining_faces)):
    f_ext_residual += f_residual[remaining_faces[i]:remaining_faces[i]+1]

# f_ext_tendon
remaining_faces = []
for face in f_pt:
    if not (face.index in f_int_tendon_labels or face.index == f_link_tendon.index):
        remaining_faces.append(face.index)

f_ext_tendon = f_pt[remaining_faces[0]:remaining_faces[0]+1]
for i in range(1,len(remaining_faces)):
    f_ext_tendon += f_pt[remaining_faces[i]:remaining_faces[i]+1]


# ---------- STEPS -------------
mdb.models['Model-1'].StaticStep(name='Loading', previous='Initial', initialInc=0.1, maxInc=0.1, nlgeom=ON)
mdb.models['Model-1'].StaticStep(name='Dynamic', previous='Loading', initialInc=0.02, maxInc=0.02, maxNumInc = 200, nlgeom=ON)
#Field output requests
mdb.models['Model-1'].FieldOutputRequest(name='F-Output-1', 
    createStepName='Loading', variables=('S', 'CSTRESS', 'EE', 'NE', 'LE', 'U'))

# ---------- INTERACTIONS ------------

#Create Interaction properties
mdb.models['Model-1'].ContactProperty('Contact_liner_emboiture')
mdb.models['Model-1'].interactionProperties['Contact_liner_emboiture'].TangentialBehavior(
    formulation=PENALTY, directionality=ISOTROPIC, slipRateDependency=OFF, 
    pressureDependency=OFF, temperatureDependency=OFF, dependencies=0, 
    table=((friction, ), ), shearStressLimit=None, maximumElasticSlip=FRACTION, 
    fraction=0.005, elasticSlipStiffness=None)
mdb.models['Model-1'].interactionProperties['Contact_liner_emboiture'].NormalBehavior(
    pressureOverclosure=HARD, allowSeparation=ON, 
    constraintEnforcementMethod=DEFAULT)

# Contact between liner and Socket
f = f_liner
#f_ext_liner = f[3:4]+f[8:10]+f[18:20]+f[21:22]+f[24:25]+f[33:34]+f[37:38]+f[39:41]+f[45:48]+f[61:62]+f[63:64]
f_ext_liner = f[11:13]+f[17:19]+f[21:23]+f[27:29]+f[30:31]+f[37:38]+f[45:46]+f[47:48]
ext_liner = a.Surface(side1Faces=f_ext_liner, name='s_ext_liner')                                                                                   
f_int_socket = f_socket
int_socket = a.Surface(side1Faces=f_int_socket, name='m_int_socket')
mdb.models['Model-1'].SurfaceToSurfaceContactStd(
    name='contact_ancillary_socket', createStepName='Initial', 
    main=int_socket, secondary=ext_liner, sliding=FINITE, thickness=ON, 
    interactionProperty='Contact_liner_emboiture', adjustMethod=OVERCLOSED, 
    initialClearance=OMIT, datumAxis=None, clearanceRegion=None, tied=OFF)

mdb.models['Model-1'].interactions['contact_ancillary_socket'].setValuesInStep(
    stepName='Loading', interferenceType=SHRINK_FIT)

# tie residual and liner
ext_residual = a.Surface(side1Faces=f_ext_residual + f_ext_tendon, name='s_ext_residual')  
f = f_liner 
#f_int_liner = f[1:2]+f[11:12]+f[15:17]+f[22:23]+f[30:32]+f[34:35]+f[36:37]+f[44:45]+f[48:49]+f[53:54]+f[55:56]+f[57:60]
f_int_liner = f[3:4]+f[8:10]+f[13:14]+f[15:17]+f[26:27]+f[32:33]+f[39:40]+f[41:44]
int_liner = a.Surface(side1Faces=f_int_liner, name='m_int_liner')
mdb.models['Model-1'].Tie(name='Tie_residual_liner', main=int_liner, secondary=ext_residual, 
    positionToleranceMethod=COMPUTED, adjust=OFF, tieRotations=ON, thickness=ON)

# tie patellar tendon and residual
region1=a.Surface(side1Faces=f_link_residual, name='m_Surf-1')
region2=a.Surface(side1Faces=f_link_tendon, name='s_Surf-1')
mdb.models['Model-1'].Tie(name='Tie_tendon', main=region1, secondary=region2, 
    positionToleranceMethod=COMPUTED, adjust=ON, tieRotations=ON, thickness=ON)

# ---------- CREATE CONSTRAINTS --------------

# ----------- REFERENCE POINTS -----------
# TIBIA
rp = p_tibia.ReferencePoint(point=(knee[0], knee[1], knee[2])).id # knee joint center
RP_tibia = p_tibia.Set(referencePoints=(p_tibia.referencePoints[rp], ), name='RP-tibia')
# PATELLA
rp = p_patella.ReferencePoint(point=(knee[0], knee[1], knee[2])).id # knee joint center
RP_patella = p_patella.Set(referencePoints=(p_patella.referencePoints[rp], ), name='RP-patella')
# CONDYLES
rp = p_condyles.ReferencePoint(point=(knee[0], knee[1], knee[2])).id # knee joint center
RP_condyles = p_condyles.Set(referencePoints=(p_condyles.referencePoints[rp], ), name='RP-condyles')

# ---------- RIGID BODIES ------------
# TIBIA
region1=a.instances['tibia'].sets['RP-tibia']
e = a.instances['tibia'].elements
region2 = a.Set(elements = e, name = 'Set-tibia')
mdb.models['Model-1'].RigidBody(name = 'RIGID-TIBIA', refPointRegion = region1, bodyRegion = region2)
# PATELLA
region1=a.instances['patella'].sets['RP-patella']
e = a.instances['patella'].elements
region2 = a.Set(elements = e, name = 'Set-patella')
mdb.models['Model-1'].RigidBody(name = 'RIGID-PATELLA', refPointRegion = region1, bodyRegion = region2)
# CONDYLES
region1=a.instances['condyles'].sets['RP-condyles']
e = a.instances['condyles'].elements
region2 = a.Set(elements = e, name = 'Set-condyles')
mdb.models['Model-1'].RigidBody(name = 'RIGID-CONDYLES', refPointRegion = region1, bodyRegion = region2)

# ----------- TIE BONES AND SOFT TISSUES -------------

int_residual = a.Surface(side1Faces=f_int_residual + f_int_tendon, name='s_int_residual')
n1 = a.instances['tibia'].nodes
n2 = a.instances['condyles'].nodes
n3 = a.instances['patella'].nodes
ext_bones = a.Set(nodes = n1 + n2 + n3, name='m_ext_bones')
mdb.models['Model-1'].Tie(name = 'tie_residual_bones', main = ext_bones, secondary = int_residual, 
    positionToleranceMethod = SPECIFIED, positionTolerance = 8.0, adjust = OFF, tieRotations = OFF, thickness = ON)

# ------------ ROTULE GENOU ------------

region1=a.instances['condyles'].sets['RP-condyles']
region2=a.instances['tibia'].sets['RP-tibia']
region3=a.instances['patella'].sets['RP-patella']
mdb.models['Model-1'].MultipointConstraint(name = 'JOIN_ROT', controlPoint = region1, surface = region2, mpcType = TIE_MPC, 
    userMode = DOF_MODE_MPC, userType = 0, csys = None)
mdb.models['Model-1'].MultipointConstraint(name = 'JOIN_ROT2', controlPoint = region1, surface = region3, mpcType = TIE_MPC, 
    userMode = DOF_MODE_MPC, userType = 0, csys = None)

# ---------- LOADING -----------

# AMPLITUDE
mdb.models['Model-1'].SmoothStepAmplitude(name='Amp-SMOOTHSTEP', timeSpan=STEP, 
    data=((0.0, 0.0), (1.0, 1.0)))
mdb.models['Model-1'].SmoothStepAmplitude(name='Amp-SMOOTHSTEP2', timeSpan=STEP, 
    data=((0.0, 1.0), (1.0, 1.0)))
    
# COUPLING SOCKET
rp = a.ReferencePoint(point=(ankle[0], ankle[1], ankle[2])).id # ankle center
RP_socket = a.Set(referencePoints=(a.referencePoints[rp], ), name='RP-socket')
mdb.models['Model-1'].DisplacementBC(name='encastrement_ankle', 
    createStepName = 'Initial', region = RP_socket, u1 = SET, u2 = SET, u3 = SET, ur1 = SET, 
    ur2 = SET, ur3 = SET, amplitude = UNSET, distributionType = UNIFORM, fieldName = '', localCsys = datum)
mdb.models['Model-1'].boundaryConditions['encastrement_ankle'].deactivate('Loading')
bottom_emboiture=a.Set(faces=f_socket[39:41]+f_socket[50:55], name='s_bottom_emboiture')
mdb.models['Model-1'].Coupling(name='lower_constraint', controlPoint=RP_socket, 
    surface=bottom_emboiture, influenceRadius=WHOLE_SURFACE, couplingType=KINEMATIC, 
    localCsys=None, u1=ON, u2=ON, u3=ON, ur1=ON, ur2=ON, ur3=ON)


# ENCASTREMENT CONDYLES
region_condyles = a.instances['condyles'].sets['RP-condyles']
mdb.models['Model-1'].DisplacementBC(name='stump_positionning', createStepName='Loading', 
    region=region_condyles, u1=0.0, u2=0.0, u3=0.0, ur1=0.0, ur2=0.0, ur3=0.0, amplitude = '', 
    fixed=OFF, distributionType=UNIFORM, fieldName='', localCsys=None)

# LOADING
# ------------- Dynamic LOADING -------------
fullMoment = './data/full_moment.txt'
fullEffort = './data/full_effort.txt'

with open(fullEffort, 'r') as file:
    effort_lines = file.readlines()

with open(fullMoment, 'r') as file:
    moment_lines = file.readlines()

time_step = 0.02  # Gait cycle divided into steps of 2percent
force_data = [(i * time_step, -float(line.split()[0]), -float(line.split()[1]), -float(line.split()[2])) for i, line in enumerate(effort_lines)]
moment_data = [(i * time_step, -float(line.split()[0]), -float(line.split()[1]), -float(line.split()[2])) for i, line in enumerate(moment_lines)]


# Create amplitude for each force component
mdb.models['Model-1'].TabularAmplitude(name='Amplitude_cf1', timeSpan=STEP, data=[(time, cf1) for time, cf1, _, _ in force_data])
mdb.models['Model-1'].TabularAmplitude(name='Amplitude_cf2', timeSpan=STEP, data=[(time, cf2) for time, _, cf2, _ in force_data])
mdb.models['Model-1'].TabularAmplitude(name='Amplitude_cf3', timeSpan=STEP, data=[(time, cf3) for time, _, _, cf3 in force_data])

# Create amplitude for each moment component
mdb.models['Model-1'].TabularAmplitude(name='Amplitude_m3', timeSpan=STEP, data=[(time, m3) for time, _, _, m3 in moment_data])

# Applying static load and moment in step Loads
region = a.sets['RP-socket']
mdb.models['Model-1'].ConcentratedForce(name='force1', createStepName='Loading',
                                        region=region,
                                        cf1=float(force_data[0][1])*subject_weight, cf2=0, cf3=0,
                                        amplitude='Amp-SMOOTHSTEP',
                                        distributionType=UNIFORM, field='', localCsys=datum)
mdb.models['Model-1'].ConcentratedForce(name='force2', createStepName='Loading',
                                        region=region,
                                        cf1=0, cf2=float(force_data[0][2])*subject_weight, cf3=0,
                                        amplitude= 'Amp-SMOOTHSTEP',
                                        distributionType=UNIFORM, field='', localCsys=datum)
mdb.models['Model-1'].ConcentratedForce(name='force3', createStepName='Loading',
                                        region=region,
                                        cf1=0, cf2=0, cf3=float(force_data[0][3])*subject_weight,
                                        amplitude='Amp-SMOOTHSTEP',
                                        distributionType=UNIFORM, field='', localCsys=datum)

mdb.models['Model-1'].Moment(name='moment3', createStepName='Loading',
							region=region,
							cm1=0, cm2=0, cm3=float(moment_data[0][3])*subject_weight*1000,
							amplitude='Amp-SMOOTHSTEP',
							distributionType=UNIFORM, field='', localCsys=datum)

# Applying dynamic forces using defined amplitudes
mdb.models['Model-1'].loads['force1'].setValuesInStep(stepName='Dynamic', cf1=subject_weight, amplitude='Amplitude_cf1')
mdb.models['Model-1'].loads['force2'].setValuesInStep(stepName='Dynamic', cf2=subject_weight, amplitude='Amplitude_cf2')
mdb.models['Model-1'].loads['force3'].setValuesInStep(stepName='Dynamic', cf3=subject_weight, amplitude='Amplitude_cf3')

# Applying dynamic moments using defined amplitudes
mdb.models['Model-1'].loads['moment3'].setValuesInStep(stepName='Dynamic', cm3=subject_weight*1000, amplitude='Amplitude_m3')         

# ---------- MESH -------------

#Assign Element types : Socket
elemType1 = mesh.ElemType(elemCode=S4, elemLibrary=STANDARD, secondOrderAccuracy=OFF)
elemType2 = mesh.ElemType(elemCode=S3, elemLibrary=STANDARD)
p_socket.setElementType(regions=(f_socket, ), elemTypes=(elemType1, elemType2))

#Socket
p_socket.setMeshControls(regions=p_socket.faces, elemShape=QUAD, technique=SWEEP)
p_socket.seedPart(size=mesh_size, deviationFactor=0.1, minSizeFactor=0.1)
p_socket.generateMesh()

#Assign Element types : residual

elemType1 = mesh.ElemType(elemCode=C3D20H, elemLibrary=STANDARD)
elemType2 = mesh.ElemType(elemCode=C3D15, elemLibrary=STANDARD)
elemType3 = mesh.ElemType(elemCode=C3D10H, elemLibrary=STANDARD)
p_residual.setElementType(regions=(p_residual.cells, ), elemTypes=(elemType1, elemType2, elemType3))
p_pt.setElementType(regions=(p_pt.cells, ), elemTypes=(elemType1, elemType2, elemType3))
p_liner.setElementType(regions=(p_liner.cells, ), elemTypes=(elemType1, elemType2, elemType3))

#Residual
p_residual.setMeshControls(regions=p_residual.cells, elemShape=TET, technique=FREE)
p_residual.seedPart(size=mesh_size, deviationFactor=0.1, minSizeFactor=0.1)
p_residual.generateMesh()

p_pt.setMeshControls(regions=p_pt.cells, elemShape=TET, technique=FREE)
p_pt.seedPart(size=mesh_size, deviationFactor=0.1, minSizeFactor=0.1)
p_pt.generateMesh()

# liner
p_liner.seedPart(size=mesh_size, deviationFactor=0.1, minSizeFactor=0.1)
p_liner.generateMesh()

# ---------- CREATE SETS FROM SENSORS NODES -------------

# Read data from txt file
posFile = './data/sensors_centers.txt'
posFile = open(posFile, 'r')
lines = posFile.readlines()
    
sensors_name = [];
sensors_loc = np.zeros((len(lines), 3));
sensors_normals = np.zeros((len(lines), 3));
for s in range(len(lines)):
    val = lines[s].split()
    sensors_loc[s] = val[1:4]
    sensors_normals[s] = val[4:7]
    sensors_name.append(str(val[0]))

radius = 8

int_socket = a.Surface(side1Faces=f_int_socket, name='m_int_socket')
insideSet = a.Set(faces=f_int_socket, name='Inside')
for ss in range(len(sensors_name)):
    pointOn = sensors_loc[ss]
    normal = sensors_normals[ss]
    
    int_socket = a.Surface(side1Faces=f_int_socket, name='m_int_socket')
    insideSet = a.Set(faces=f_int_socket, name='Inside')
    
    # Select nodes inside a cylinder centered on pointOn
    c1 = tuple(np.add(pointOn, 20*normal))
    c2 = tuple(np.subtract(pointOn, 20*normal))
    
    sensorNodes = insideSet.nodes.getByBoundingCylinder(c1, c2, radius)
    sensorSet = a.Set(nodes=sensorNodes, name='sensorNodes-'+sensors_name[ss])
    
    # field output 
    mdb.models['Model-1'].FieldOutputRequest(name=sensors_name[ss] + '_meas', 
        createStepName='Loading', variables=('CSTRESS', ), region=sensorSet, 
        sectionPoints=DEFAULT, position=NODES, rebar=EXCLUDE)
    

# ----------- EXPORT MODEL AS INP ------------

# create Job
mdb.Job(name='Job-dynamic', model='Model-1', description='', type=ANALYSIS,
        atTime=None, waitMinutes=0, waitHours=0, queue=None, memory=90, 
        memoryUnits=PERCENTAGE, getMemoryFromAnalysis=True, 
        explicitPrecision=SINGLE, nodalOutputPrecision=SINGLE, echoPrint=OFF, 
        modelPrint=OFF, contactPrint=OFF, historyPrint=OFF, userSubroutine='', 
        scratch='', resultsFormat=ODB, multiprocessingMode=DEFAULT)

# Write .inp
mdb.jobs['Job-dynamic'].writeInput(consistencyChecking=OFF)